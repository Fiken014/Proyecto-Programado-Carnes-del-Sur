using CarnesDelSurMVC.Models;
using Microsoft.AspNetCore.Identity;

namespace CarnesDelSurMVC.Services
{
    public class DatabaseInitializer
    {
        public static async Task SeedDataAsync(UserManager<ApplicationUser>? userManager,
            RoleManager<IdentityRole>? roleManager, IConfiguration configuration)
        {
            if (userManager == null || roleManager == null)
            {
                Console.WriteLine("userManager o roleManager es nulo => salir");
                return;
            }

            // Comprobar si tenemos el rol de administrador o no
            var exists = await roleManager.RoleExistsAsync("admin");
            if (!exists)
            {
                Console.WriteLine("El rol de administrador no está definido y se creará");
                await roleManager.CreateAsync(new IdentityRole("admin"));
            }

            // Comprobar si tenemos el rol de cliente o no
            exists = await roleManager.RoleExistsAsync("cliente");
            if (!exists)
            {
                Console.WriteLine("El rol de cliente no está definido y se creará");
                await roleManager.CreateAsync(new IdentityRole("cliente"));
            }

            // Comprobar si tenemos al menos un usuario administrador o no
            var adminUsers = await userManager.GetUsersInRoleAsync("admin");
            if (adminUsers.Any())
            {
                Console.WriteLine("El usuario administrador ya existe => salir");
                return;
            }

            // Credenciales del administrador inicial: se leen de configuración (User Secrets),
            // nunca se escriben en el código ni se muestran en consola.
            var adminEmail = configuration["AdminSettings:Email"] ?? "admin@admin.com";
            var initialPassword = configuration["AdminSettings:InitialPassword"];

            if (string.IsNullOrWhiteSpace(initialPassword))
            {
                throw new InvalidOperationException(
                    "Falta 'AdminSettings:InitialPassword'. Configurala en User Secrets antes de ejecutar la aplicación.");
            }

            // Crear el usuario administrador
            var user = new ApplicationUser()
            {
                Nombre = "Admin",
                Apellido = "Admin",
                UserName = adminEmail, // UserName se utilizará para autenticar al usuario
                Email = adminEmail,
                CreadoEn = DateTime.Now,
            };

            var result = await userManager.CreateAsync(user, initialPassword);
            if (result.Succeeded)
            {
                // Establecer el rol del usuario
                await userManager.AddToRoleAsync(user, "admin");
                Console.WriteLine("Usuario administrador creado correctamente. Cambie la contraseña inicial.");
            }
            else
            {
                Console.WriteLine("No se pudo crear el administrador: " +
                    string.Join("; ", result.Errors.Select(e => e.Description)));
            }
        }
    }
}
